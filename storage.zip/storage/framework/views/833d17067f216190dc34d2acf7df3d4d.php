<?php $__env->startSection('title', 'Tambah Ruangan'); ?>

<?php $__env->startSection('content'); ?>
<div class="h-full flex-1 overflow-y-auto pb-8 custom-scrollbar">
    <div class="max-w-3xl mx-auto w-full">
        
        <div class="flex items-center gap-4 mb-6 animate-card" style="animation-delay: 0ms;">
            <a href="<?php echo e(route('lokasi.index')); ?>" class="p-2 rounded-xl bg-white border border-gray-200 text-gray-500 hover:text-[#2548cc] hover:border-[#2548cc] hover:bg-blue-50 transition-all shadow-sm">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
            </a>
            <div>
                <h1 class="text-2xl font-extrabold text-[#1a2f6e]">Tambah Ruangan</h1>
                <p class="text-sm text-gray-500 mt-1">Tambahkan data lokasi ruangan baru ke sistem.</p>
            </div>
        </div>

        
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 sm:p-8 animate-card" style="animation-delay: 100ms;">
            <form method="POST" action="<?php echo e(route('lokasi.store')); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>

                
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
                        Nama Ruangan <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="nama" value="<?php echo e(old('nama')); ?>" required
                        placeholder="Dapur, Lab Komputer, Ruang Rapat, dll"
                        class="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#2548cc]/20 focus:border-[#2548cc] transition-all bg-gray-50 focus:bg-white <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 bg-red-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1.5"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Gedung</label>
                        <input type="text" name="gedung" value="<?php echo e(old('gedung')); ?>"
                            placeholder="A, B, C, dll"
                            class="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#2548cc]/20 focus:border-[#2548cc] transition-all bg-gray-50 focus:bg-white">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Lantai</label>
                        <input type="text" name="lantai" value="<?php echo e(old('lantai')); ?>"
                            placeholder="01, 02, 03, dll"
                            class="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#2548cc]/20 focus:border-[#2548cc] transition-all bg-gray-50 focus:bg-white">
                    </div>
                </div>

                
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Jenis Ruangan</label>
                    <input type="text" name="jenis" value="<?php echo e(old('jenis')); ?>"
                        placeholder="Lab, Gudang, Ruang Kelas, dll"
                        class="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#2548cc]/20 focus:border-[#2548cc] transition-all bg-gray-50 focus:bg-white">
                </div>

                
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Keterangan</label>
                    <textarea name="keterangan" rows="4"
                        placeholder="Keterangan tambahan mengenai ruangan..."
                        class="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#2548cc]/20 focus:border-[#2548cc] transition-all bg-gray-50 focus:bg-white resize-none"><?php echo e(old('keterangan')); ?></textarea>
                </div>

                
                <div class="pt-6 border-t border-gray-100 flex items-center justify-end gap-3">
                    <a href="<?php echo e(route('lokasi.index')); ?>"
                        class="px-6 py-2.5 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-100 transition-colors">
                        Batal
                    </a>
                    <button type="submit"
                        class="bg-[#2548cc] text-white px-6 py-2.5 rounded-xl text-sm font-semibold shadow-sm hover:bg-blue-800 hover:-translate-y-0.5 hover:shadow-md transition-all duration-300 flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                        Simpan Ruangan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\inventaris-app\resources\views/lokasi/create.blade.php ENDPATH**/ ?>