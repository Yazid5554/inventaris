
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.js"></script><?php /**PATH D:\inventaris-app\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>